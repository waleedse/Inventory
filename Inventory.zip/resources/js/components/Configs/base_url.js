module.exports={
    image_base:'/images/'
}
